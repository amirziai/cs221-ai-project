import unittest


class UnitTests(unittest.TestCase):
    def test_init(self):
        # dummy test for travis
        self.assertEqual(True, True)


if __name__ == '__main__':
    unittest.main()
